# bs-system-1.0
this is batch system on the cmd basic
